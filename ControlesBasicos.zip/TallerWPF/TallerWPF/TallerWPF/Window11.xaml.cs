﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TallerWPF
{
    /// <summary>
    /// Lógica de interacción para Window11.xaml
    /// </summary>
    public partial class Window11 : Window
    {
        public Window11()
        {
            InitializeComponent();
            cmbColors.ItemsSource = typeof(Colors).GetProperties();
        }

        private void cmbColors_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            String cadena = cmbColors.SelectedItem.ToString();
            String control = cadena.Split(' ')[1].TrimStart(' ');
            MessageBox.Show(control);
        }
    }
}
